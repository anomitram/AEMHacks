/*************************************************************************
 *
 * ADOBE CONFIDENTIAL
 * ___________________
 *
 *  Copyright 2013 Adobe Systems Incorporated
 *  All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains
 * the property of Adobe Systems Incorporated and its suppliers,
 * if any.  The intellectual and technical concepts contained
 * herein are proprietary to Adobe Systems Incorporated and its
 * suppliers and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material
 * is strictly forbidden unless prior written permission is obtained
 * from Adobe Systems Incorporated.
 **************************************************************************/
/* global Class: true */
/* jshint strict: false */
(function ($, CUI) {

  //'use strict';
  CUI.rte.ui.cui.LinkBaseDialog = new Class({

    extend: CUI.rte.ui.cui.AbstractDialog,

    toString: 'LinkBaseDialog',

    getDataType: function () {
      return 'link';
    },

    handleLinkSuccess: function (href) {
      if (href) {
        this.hrefField.value = href;
      }
    },

    // config.linkOptionsLoader - to load options for path browser to complete internal links
    initialize: function (config) {
      this.config = config;
      this.context = this.editorKernel.getEditContext();
      this.touchScrollLimiter = this.context.getState('CUI.touchScrollLimiter');

      this.hrefField = this.$dialog.find('input.rte-linkfield[is="coral-textfield"]')[0];

      // Reset the value of items with "" value attributes. The handlebars template uses el.setAttribute("value", "")
      // to set the initial value. This doesn't update the internal _value property as no change is detected.
      // As a result the textContent of the item is taken as the value, which is undesired.
      // See CUI-6837
      var items = this._elements.targetSelect.items.getAll();
	  //var eventItems = this._elements.eventSelect.items.getAll();
      
	  for (var i = 0; i < items.length; i++) {
          if (items[i].getAttribute('value') === '') {
          items[i].value = '';
        }
      }
	  
	 /* for (var i = 0; i < eventItems.length; i++) {
          if (eventItems[i].getAttribute('value') === '') {
          eventItems[i].value = '';
        }
      }*/

      this._elements.targetSelect.value = '';
	  //this._elements.eventSelect.value = '';

      // Cancel all keydown events
      this.$dialog.on('keydown', this.handleKeyDown);
    },

    onShow: function () {
      if (!CUI.rte.Common.ua.isTouch) {
        var self = this;
        window.setTimeout(function () {
          $(self.hrefField).focus();
        }, 1);
      }
      if(this.touchScrollLimiter) {
        this.touchScrollLimiter.suspend();
      }
    },

    onHide: function() {
      if(this.touchScrollLimiter) {
        this.touchScrollLimiter.reactivate();
      }
    },

    handleKeyDown: function (event) {
      event.stopPropagation();
    },

    preprocessModel: function () {
      if (this.objToEdit && this.objToEdit.dom) {
        this.objToEdit.href = CUI.rte.HtmlRules.Links.getLinkHref(
          this.objToEdit.dom);
        var com = CUI.rte.Common;
        var attribNames = com.getAttributeNames(this.objToEdit.dom, false,
          function (dom, attribName, attribNameLC) {
            // exclude href, rte_href & target from generic attribute handling,
            // as they are handled explicitly and not generically
            return attribNameLC === com.HREF_ATTRIB || attribNameLC === 'href' ||
              attribNameLC === 'target';
          });
        for (var i = 0; i < attribNames.length; i++) {
          var attribName = attribNames[i];
			//alert("attributename==>"+attribName);
          var value = com.getAttribute(this.objToEdit.dom, attribName);
          if (typeof value !== 'undefined') {
            this.objToEdit.attributes[attribName] = value;
          }
        }
      }
    },

    dlgFromModel: function () {

      var value;
      if (this.hrefField) {
        value = '';
        if (this.objToEdit) {
          var href = this.objToEdit.href;
          if (href) {
            value = href;
          }
        }
        this.hrefField.value = value;
      }
      var targetSelect = this._elements.targetSelect;
	  var eventSelect = this._elements.eventSelect;

      var titleField = this.getFieldByType('title');
	  var enstitle = this.getFieldByType('enstitle');
      var ensevents = this.getFieldByType('ensevents');
      var enscall =  this.getFieldByType('enscall');
	  
	  var event = (this.objToEdit && this.objToEdit.attributes['data-event'] && this.objToEdit.attributes['data-event']!='Select' ?
        this.objToEdit.attributes['data-event'] : null);

      var target = (this.objToEdit && this.objToEdit.target ?
        this.objToEdit.target.toLowerCase() : null);


      if (target) {
        targetSelect.items.getAll().forEach(function(elem, index) {
          if (elem.value === target) {
            elem.selected = true;
          }
        }, this);
      } else {
        targetSelect.value = '';
      }
	  
	  if (event) {
        eventSelect.items.getAll().forEach(function(elem, index) {
          if (elem.value === event) {
            elem.selected = true;
          }
        }, this);

      } else {
        eventSelect.value = '';
      }

        if (enscall) {
        value = (this.objToEdit && this.objToEdit.attributes &&
        this.objToEdit.attributes['onclick'] ?
          this.objToEdit.attributes['onclick'] : null);
        enscall.val(value);
      }


      if (enstitle) {
        value = (this.objToEdit && this.objToEdit.attributes &&
        this.objToEdit.attributes['data-enstitle'] ?
          this.objToEdit.attributes['data-enstitle'] : null);
        enstitle.val(value);
      }

       if (ensevents) {
        value = (this.objToEdit && this.objToEdit.attributes &&
        this.objToEdit.attributes['data-ensevents'] ?
          this.objToEdit.attributes['data-ensevents'] : null);
        ensevents.val(value);
      }

      if (titleField) {
        value = (this.objToEdit && this.objToEdit.attributes &&
        this.objToEdit.attributes['title'] ?
          this.objToEdit.attributes['title'] : null);
        titleField.val(value);
      }
    },

    validate: function () {

      if (this.hrefField) {
        var href = this.hrefField.value;
        if (href && (href.length > 0)) {
          return true;
        }
      }
      return false;
    },

    dlgToModel: function () {
      if (this.objToEdit) {
		
        if (this.hrefField) {
          var href = this.hrefField.value;
          if (href) {
            this.objToEdit.href = href;
          }
        }
        var targetSelect = this._elements.targetSelect;
        var target = targetSelect.value;
		var eventSelect = this._elements.eventSelect;
        var event = eventSelect.value;


        var titleField = this.getFieldByType('title');
		var enstitle = this.getFieldByType('enstitle');
      	var ensevents = this.getFieldByType('ensevents');

        if (target) {
          this.objToEdit.target = target;
        } else {
          this.objToEdit.target = null;
        }

		if (event && event!='Select') {
          this.objToEdit.attributes['data-event'] = event;

            if(enstitle && ensevents){
			 var enstitleVal = enstitle.val();
			 var enseventsVal = ensevents.val();

                 if (enstitleVal !== null && enstitleVal !== undefined && enseventsVal !== null && enseventsVal !== undefined) {

                     var componentName = "Rich Text";
                     var eventData = componentName + "|" + enstitleVal + "|" + enseventsVal;

                      var onClickMethod = "javascript:CdwTagMan.createElementPageTag(window.cdwTagManagementData.page_name, '" + eventData + "');";
                     if("partnerClick"==event){
                         onClickMethod = "javascript:CdwTagMan.createPromotionTag('Site Promotion', '" + eventData + "');";
                     }

				this.objToEdit.attributes['onclick'] = onClickMethod;

            }
         }

        } else {
          this.objToEdit.attributes['data-event'] = null;
          this.objToEdit.attributes['onclick'] = null;
        }
		
		


		 if (enstitle) {
          var enstitleVal = enstitle.val();
          if (enstitleVal !== null && enstitleVal !== undefined) {
            this.objToEdit.attributes['data-enstitle'] = enstitleVal;
          }
        }

        if (ensevents) {
          var enseventsVal = ensevents.val();
          if (enseventsVal !== null && enseventsVal !== undefined) {
            this.objToEdit.attributes['data-ensevents'] = enseventsVal;
          }
        }

        if (titleField) {
          var titleVal = titleField.val();
          if (titleVal !== null && titleVal !== undefined) {
            this.objToEdit.attributes['title'] = titleVal;
          }
        }
      }
    },

    postprocessModel: function () {
      var linkRules = this.getParameter('linkRules');
      if (linkRules) {
        linkRules.applyToObject(this.objToEdit);
      }
    }

  });


})(window.jQuery, window.CUI);
